gdjs.game_95overCode = {};

gdjs.game_95overCode.conditionTrue_0 = {val:false};
gdjs.game_95overCode.condition0IsTrue_0 = {val:false};


gdjs.game_95overCode.eventsList0 = function(runtimeScene) {

};

gdjs.game_95overCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.game_95overCode.eventsList0(runtimeScene);
return;

}

gdjs['game_95overCode'] = gdjs.game_95overCode;
