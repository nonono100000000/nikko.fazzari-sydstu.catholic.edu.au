gdjs.CountDownCode = {};
gdjs.CountDownCode.GDTimerTextObjects1= [];
gdjs.CountDownCode.GDTimerTextObjects2= [];

gdjs.CountDownCode.conditionTrue_0 = {val:false};
gdjs.CountDownCode.condition0IsTrue_0 = {val:false};
gdjs.CountDownCode.condition1IsTrue_0 = {val:false};


gdjs.CountDownCode.eventsList0 = function(runtimeScene) {

{



}


{



}


{


gdjs.CountDownCode.condition0IsTrue_0.val = false;
{
gdjs.CountDownCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.CountDownCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "CountDown");
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("TimerText"), gdjs.CountDownCode.GDTimerTextObjects1);
{for(var i = 0, len = gdjs.CountDownCode.GDTimerTextObjects1.length ;i < len;++i) {
    gdjs.CountDownCode.GDTimerTextObjects1[i].setString(gdjs.evtTools.common.toString(Math.round(Math.abs(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "CountDown") - 8640000))));
}
}}

}


{



}


{


gdjs.CountDownCode.condition0IsTrue_0.val = false;
{
gdjs.CountDownCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "CountDown") >= 8640000;
}if (gdjs.CountDownCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game_over", false);
}}

}


};

gdjs.CountDownCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CountDownCode.GDTimerTextObjects1.length = 0;
gdjs.CountDownCode.GDTimerTextObjects2.length = 0;

gdjs.CountDownCode.eventsList0(runtimeScene);
return;

}

gdjs['CountDownCode'] = gdjs.CountDownCode;
